import React from 'react'

 const HomeComponent=()=>{
  return (
    <div>HomeComponent</div>
  )
}
export default HomeComponent;
